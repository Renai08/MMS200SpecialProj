AFRAME.registerComponent('switch-rooms', {
        schema: {
          url: { type: 'string' }
        },
        init: function () {
          this.el.addEventListener('click', () => {
            window.location.href = this.data.url;
          });
        }
      });