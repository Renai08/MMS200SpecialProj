AFRAME.registerComponent('teleport-sections', {
  init: function () {
    const user = document.querySelector('#user');

    //Directory
    /*
    1 - Switch Room 
    2 - Intro to Virtual Exhibit +  Identification and Discussion of Significance of Virtual Exhibits, 
    P-pop groups with concept or aim to promote Philippine history, arts, and culture, 
    or the combination of both.
    */
    
    
    window.addEventListener('keydown', (event) => {
      if (event.key === '1') {
        user.setAttribute('position', { x: 0, y: 16, z: 12.5 });
        user.setAttribute('rotation', { x: 0, y: 0, z: 0 });
      } else if (event.key === '2') {
        user.setAttribute('position', { x: 0, y: 16, z: -30 });
        user.setAttribute('rotation', { x: 0, y: 0, z: 0 });
      } else if (event.key === '3') {
        user.setAttribute('position', { x: 0, y: 16, z: 30 });
        user.setAttribute('rotation', { x: 0, y: 180, z: 0 });
      } 
    });
  }
});
