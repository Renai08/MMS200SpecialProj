AFRAME.registerComponent('view-ppt', {
  schema: {
    url: { type: 'string' }
  },
  init: function () {
    this.el.addEventListener('click', () => {
      window.open(this.data.url, '_blank');
    });
  }
});