AFRAME.registerComponent('open-ins', {
  schema: {
    url: { type: 'string' }
  },
  init: function () {
    this.el.addEventListener('click', () => {
      window.open('https://www.canva.com/design/DAGOq05Tfdg/PLlUQNEvyIjRnbPnjdr1zA/view?utm_content=DAGOq05Tfdg&utm_campaign=designshare&utm_medium=link&utm_source=viewer', '_blank');
    });
  }
});